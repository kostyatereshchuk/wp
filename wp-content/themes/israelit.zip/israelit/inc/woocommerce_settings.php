<?php

class WC_Settings_Tab_Demo {
    /**
     * Bootstraps the class and hooks required actions & filters.
     */
    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50 );
        add_action( 'woocommerce_settings_tabs_settings_tab_demo', __CLASS__ . '::settings_tab' );
        add_action( 'woocommerce_update_options_settings_tab_demo', __CLASS__ . '::update_settings' );
    }

    /**
     * Add a new settings tab to the WooCommerce settings tabs array.
     *
     * @param array $settings_tabs Array of WooCommerce setting tabs & their labels, excluding the Subscription tab.
     * @return array $settings_tabs Array of WooCommerce setting tabs & their labels, including the Subscription tab.
     */
    public static function add_settings_tab( $settings_tabs ) {
        $settings_tabs['settings_tab_demo'] = __( 'Settings Demo Tab', 'israelit' );
        return $settings_tabs;
    }

    /**
     * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
     *
     * @uses woocommerce_admin_fields()
     * @uses self::get_settings()
     */
    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
    }

    /**
     * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
     *
     * @uses woocommerce_update_options()
     * @uses self::get_settings()
     */
    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
    }

    /**
     * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
     *
     * @return array Array of settings for @see woocommerce_admin_fields() function.
     */
    public static function get_settings() {
        $settings = array(
            'section_title' => array(
                'name'     => __( 'Section Title', 'israelit' ),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'wc_settings_tab_demo_section_title'
            ),
            'title' => array(
                'name' => __( 'Title', 'israelit' ),
                'type' => 'text',
                'desc' => __( 'This is some helper text', 'israelit' ),
                'id'   => 'wc_settings_tab_demo_title'
            ),
            'description' => array(
                'name' => __( 'Description', 'israelit' ),
                'type' => 'textarea',
                'desc' => __( 'This is a paragraph describing the setting. Lorem ipsum yadda yadda yadda. Lorem ipsum yadda yadda yadda. Lorem ipsum yadda yadda yadda. Lorem ipsum yadda yadda yadda.', 'israelit' ),
                'id'   => 'wc_settings_tab_demo_description'
            ),
            'section_end' => array(
                'type' => 'sectionend',
                'id' => 'wc_settings_tab_demo_section_end'
            )
        );
        return apply_filters( 'wc_settings_tab_demo_settings', $settings );
    }
}
WC_Settings_Tab_Demo::init();






/*
add_action( ‘woocommerce_order_status_completed’, ‘mysite_completed’);
add_action( ‘woocommerce_order_status_cancelled’, ‘mysite_cancelled’);*/


/**
 * Checks if product is gift.
 *
 * @param $product_id
 * @return bool
 */
function israelit_is_gift_product( $product_id ) {
    $terms = get_the_terms( $product_id, 'product_cat' );

    $is_gift_product = false;

    foreach ( $terms as $term ) {
        if ( $term->slug == 'gift' ) {
            $is_gift_product = true;

            break;
        }
    }

    return $is_gift_product;
}

/**
 * Creates a coupon, related to a gift product.
 *
 * @param $product_id
 */
function israelit_create_coupon_for_gift_product( $product_id, $discount ) {
    // TODO: Create a coupon, related to a gift product
}

/**
 * Removes a coupon, related to a gift product.
 *
 * @param $product_id
 */
function israelit_remove_coupon_for_gift_product( $product_id ) {
    // TODO: Remove a coupon, related to a gift product
}

/**
 * Checks an order for a gift products and creates coupons for these products.
 *
 * @param $order_id
 */
function israelit_maybe_create_gift_coupons_from_order( $order_id ) {
    $order = wc_get_order( $order_id );

    $items = $order->get_items();

    if ( empty( $items ) ) {
        return;
    }

    foreach ( $items as $item ) {
        $product_id = $item->get_product_id();

        if ( israelit_is_gift_product( $product_id ) ) {
            $discount = $item->get_total();

            israelit_create_coupon_for_gift_product( $product_id, $discount );
        }
    }
}
add_action( 'woocommerce_order_status_completed', 'israelit_maybe_create_gift_coupons_from_order' );

/**
 * Checks an order for a gift products and removes coupons for these products.
 *
 * @param $order_id
 */
function israelit_maybe_remove_gift_coupons_from_order( $order_id ) {
    $order = wc_get_order( $order_id );

    $items = $order->get_items();

    if ( empty( $items ) ) {
        return;
    }

    foreach ( $items as $item ) {
        $product_id = $item->get_product_id();

        if ( israelit_is_gift_product( $product_id ) ) {
            israelit_remove_coupon_for_gift_product( $product_id );
        }
    }
}
add_action( 'woocommerce_order_status_cancelled', 'israelit_maybe_remove_gift_coupons_from_order' );


// Test
/*add_action( 'init', function() {
    $order_id = 184;

    israelit_maybe_create_gift_coupons_from_order( $order_id );
} );*/



