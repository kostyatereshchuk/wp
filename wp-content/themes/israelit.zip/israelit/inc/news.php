<?php

/**
 * Register a news post type.
 */
function israelit_register_news_post_type() {
    register_post_type( 'news', array(
        'labels' => array(
            'name' => _x( 'News', 'post type general name', 'israelit' ),
            'singular_name' => _x( 'News Article', 'post type singular name', 'israelit' ),
            'menu_name' => _x( 'News', 'admin menu', 'israelit' ),
            'name_admin_bar' => _x( 'News Article', 'add new on admin bar', 'israelit' ),
            'add_new' => _x( 'Add New', 'book', 'israelit' ),
            'add_new_item' => __( 'Add New News Article', 'israelit' ),
            'new_item' => __( 'New News Article', 'israelit' ),
            'edit_item' => __( 'Edit News Article', 'israelit' ),
            'view_item' => __( 'View News Article', 'israelit' ),
            'all_items' => __( 'All News', 'israelit' ),
            'search_items' => __( 'Search News', 'israelit' ),
            'parent_item_colon' => __( 'Parent News:', 'israelit' ),
            'not_found' => __( 'No news found.', 'israelit' ),
            'not_found_in_trash' => __( 'No news found in Trash.', 'israelit' )
        ),
        'description' => __( 'Description.', 'israelit' ),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-megaphone',
        'query_var' => true,
        'rewrite' => array( 'slug' => 'news' ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
    ) );

    register_taxonomy('news-category', array( 'news' ), array(
        'labels' => array(
            'name' => _x( 'Categories', 'taxonomy general name', 'israelit' ),
            'singular_name' => _x( 'Category', 'taxonomy singular name', 'israelit' ),
            'search_items' =>  __( 'Search Categories', 'israelit' ),
            'all_items' => __( 'All Categories', 'israelit' ),
            'parent_item' => __( 'Parent Category', 'israelit' ),
            'parent_item_colon' => __( 'Parent Category:', 'israelit' ),
            'edit_item' => __( 'Edit Category', 'israelit' ),
            'update_item' => __( 'Update Category', 'israelit' ),
            'add_new_item' => __( 'Add New Category', 'israelit' ),
            'new_item_name' => __( 'New Category Name', 'israelit' ),
            'menu_name' => __( 'Categories', 'israelit' ),
        ),
        'hierarchical' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'news-category' ),
    ));
}
add_action( 'init', 'israelit_register_news_post_type' );